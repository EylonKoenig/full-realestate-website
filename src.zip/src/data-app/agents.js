let agents = [
    {id: 1, label: 'Tel Aviv', name: 'Tel Aviv RealEstate Tovado', description: 'Wonderful city', country: 'Israel', image: "images/cities/tel_aviv.jpg",email:"realestate@gmail.com"},
    {id: 2, label: 'Tel Aviv', name: 'Israel Sothebys International Realty', description: 'Wonderful city', country: 'Israel', image: "images/cities/new_york.jpg",email:"realestate@gmail.com"},
    {id: 3, label: 'New York', name: 'USA RealEstate', description: 'Los Angeles', country: 'United State', image: "images/cities/new_delhi.jpg",email:"realestate@gmail.com"},
    {id: 4, label: 'Canada', name: 'RE/MAX Canada', description: 'Wonderful city', country: 'Canada', image: "images/cities/barcelona.jpg",email:"realestate@gmail.com"},
    {id: 5, label: 'Madrid', name: 'Luxury real estate agency Madrid Salamanca', description: 'Wonderful city', country: 'Spain', image: "images/cities/madrid.jpg",email:"realestate@gmail.com"},
    {id: 6, label: 'London', name: 'Sothebys International Realty', description: 'Wonderful city', country: 'United Kingdom', image: "images/cities/london.jpg",email:"realestate@gmail.com"},
    {id: 7, label: 'Liverpool', name: 'Elders Real Estate', description: 'Wonderful city', country: 'United Kingdom', image: "images/cities/liverpool.jpg",email:"realestate@gmail.com"},
    {id: 8, label: 'Babruysk', name: 'Efestio Real Estate', description: 'Wonderful city', country: 'Belarus', image: "images/cities/babruysk.jpg",email:"realestate@gmail.com"},
];

export {agents};