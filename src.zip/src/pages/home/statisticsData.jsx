import React from 'react';

class StatisticsData extends React.Component {
    render () {
        return(
            <div className="container-fluid">
                <div className="warperdetails">
                    <div className="detailsheader">
                        <div>
                            <h2>What's happening in San Francisco, CA</h2>
                        </div>
                    </div>
                </div>
                <div className="row justify-content-around details">
                    <div className="col-6 col-md-2 text-center">
                        <a href="/">
                            <span>1,291</span>
                            <p>Homes for sale</p>
                        </a>
                    </div>
                    <div className="col-6 col-md-2 text-center">
                        <a href="/">
                            <span>1,291</span>
                            <p>Homes for sale</p>
                        </a>
                    </div>
                    <div className="col-6 col-md-2 text-center">
                        <a href="/">
                            <span>1,291</span>
                            <p>Homes for sale</p>
                        </a>
                    </div>
                    <div className="col-6 col-md-2 text-center">
                        <a href="/">
                            <span>1,291</span>
                            <p>Homes for sale</p>
                        </a>
                    </div>
                    <div className="col-6 col-md-2 text-center">
                        <a href="/">
                            <span>1,291</span>
                            <p>Homes for sale</p>
                        </a>
                    </div>
                </div>
            </div>
        );
    }}
export default StatisticsData;

