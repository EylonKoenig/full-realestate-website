import React from 'react';

class FooterAD extends React.Component {
    render () {
        return(
            <div className="commercial text-center">
                <div className="my-4">
                    <a href="/">
                        <img src="https://tpc.googlesyndication.com/simgad/13245008257885262537" width="600" height="70" alt="" className="img_ad"/>
                    </a>
                </div>
            </div>
        );
    }}
export default FooterAD;

